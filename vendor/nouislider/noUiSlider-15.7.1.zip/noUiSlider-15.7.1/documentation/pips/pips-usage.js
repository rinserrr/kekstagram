// returns the created HtmlElement
var pips = slider.noUiSlider.pips(/* options */);
